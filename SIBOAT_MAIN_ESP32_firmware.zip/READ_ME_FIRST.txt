SIBOAT firmware build - SIBOAT_MAIN_ESP32
Built:   2026-10-01 00:52 UTC
Commit:  3dcf240
Core:    esp32:esp32@2.0.17
Board:   esp32:esp32:esp32:PartitionScheme=huge_app

WHAT TO FLASH
  SIBOAT_MAIN_ESP32_ALL-IN-ONE_flash-at-0x0.bin  ->  write it at address 0x0
  (it already contains bootloader + partition table + app)

PC with esptool:
  python -m esptool --chip esp32 --baud 460800 write_flash 0x0 SIBOAT_MAIN_ESP32_ALL-IN-ONE_flash-at-0x0.bin
  (if it fails, retry with --baud 115200)

Browser flasher (Chrome or Edge):  https://espressif.github.io/esptool-js/
  Connect -> flash address 0x0 -> choose the ALL-IN-ONE file -> Program

ESP32-CAM only: if your programmer board does not do it automatically,
connect GPIO0 to GND, press RESET, flash, then remove the wire and press RESET.

Only if you cannot use the all-in-one file, flash the files in separate-parts/ at:
  0x1000   *.bootloader.bin
  0x8000   *.partitions.bin
  0xe000   boot_app0.bin
  0x10000  *.ino.bin
